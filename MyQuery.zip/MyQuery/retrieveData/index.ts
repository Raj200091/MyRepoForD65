import {IInputs, IOutputs} from "./generated/ManifestTypes";

export class retrieveData implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _context: ComponentFramework.Context<IInputs>;
    /**
     * Empty constructor.
     */
    constructor()
    {

    }

    /**
     * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.
     * Data-set values are not initialized here, use updateView.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.
     * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.
     * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.
     * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.
     */
    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container:HTMLDivElement): void
    {
        // Add control initialization code

        let entityId = (<any>context.mode).contextInfo.entityId;
        let entityTypeName = (<any>context.mode).contextInfo.entityTypeName;
        // const temp = document.createAttribute('h1');
        // temp.textContent  ='Entity Id==> ' + entityId + ' Entity Name ==>'+ entityTypeName;
        // container.appendChild(temp);
       console.log('the record Id : '+entityId);
       console.log('the entity name : '+entityTypeName);

       this._context = context;

       // Assume 'fetchXml' contains your Fetch XML query
       const fetchXml = `<fetch 
       output-format='xml-platform'
       version='1.0'
       distinct='false'>
       <entity name ='contact'>
          <attribute name ='fullname' />
          <attribute name ='jobtitle' />
          <attribute name ='annualincome' />
       </entity>
    </fetch>`;
    console.log('fetchXml',fetchXml);

       // Make a request to the Dynamics 365 Web API
       //context.webAPI.retrieveMultipleRecords()
       context.webAPI.retrieveMultipleRecords("contact","?fetchXml=" + fetchXml)
           .then(
               (result) => {
                   // Process the retrieved records
                   console.log('this is a result for multiple records : '+JSON.stringify(result.entities));
                   // renderTable(result.entities);
               },
               (error) => {
                   // Handle errors
                   console.error(error.message);
               }
           );
       // Add control initialization code

       context.webAPI.retrieveRecord("account",entityId, "?$select=name,revenue")
           .then(
               (result) => {
                   // Process the retrieved records
                   console.log('this is the record for the specific id and using oData : '+JSON.stringify(result));
                   // renderTable(result.entities);
               },
               (error) => {
                   // Handle errors
                   console.error(error.message);
               }
           );

           context.webAPI.retrieveRecord("account",entityId,"?fetchXml=" + fetchXml)
           .then(
               (result) => {
                   // Process the retrieved records
                   console.log('A record for the specific id and using FetchXML : '+JSON.stringify(result.entities));
                   // renderTable(result.entities);
               },
               (error) => {
                   // Handle errors
                   console.error(error.message);
               }
           );
    }


    /**
     * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.
     * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions
     */
    public updateView(context: ComponentFramework.Context<IInputs>): void
    {
        // Add code to update control view
    }

    /**
     * It is called by the framework prior to a control receiving new data.
     * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”
     */
    public getOutputs(): IOutputs
    {
        return {};
    }

    /**
     * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.
     * i.e. cancelling any pending remote calls, removing listeners, etc.
     */
    public destroy(): void
    {
        // Add code to cleanup control if necessary
    }
}
